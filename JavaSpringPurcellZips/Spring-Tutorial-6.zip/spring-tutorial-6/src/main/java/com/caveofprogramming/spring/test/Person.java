package com.caveofprogramming.spring.test;

public class Person {

	public void speak() {
		System.out.println("Hello! I'm a person.");
	}

}
