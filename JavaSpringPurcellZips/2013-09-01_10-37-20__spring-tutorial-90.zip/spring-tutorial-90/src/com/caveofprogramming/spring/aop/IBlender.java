package com.caveofprogramming.spring.aop;

public interface IBlender {

	public abstract void blend();

}