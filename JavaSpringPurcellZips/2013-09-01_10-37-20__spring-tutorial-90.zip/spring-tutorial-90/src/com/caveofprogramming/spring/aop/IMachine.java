package com.caveofprogramming.spring.aop;

public interface IMachine {
	public void start();
}
