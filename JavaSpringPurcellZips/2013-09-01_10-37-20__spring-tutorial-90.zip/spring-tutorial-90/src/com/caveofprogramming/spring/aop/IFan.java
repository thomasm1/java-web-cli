package com.caveofprogramming.spring.aop;

public interface IFan {

	public abstract void activate(int level);

}