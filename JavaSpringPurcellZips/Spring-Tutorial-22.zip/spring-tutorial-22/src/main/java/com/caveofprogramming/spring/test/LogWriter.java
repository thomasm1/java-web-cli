package com.caveofprogramming.spring.test;

public interface LogWriter {
	public void write(String text);
}
