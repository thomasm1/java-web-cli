package com.caveofprogramming.spring.test;

import java.util.List;

public class OffersDAO {
	
	public List<Offer> getOffers() {
		return null;
	}
}
