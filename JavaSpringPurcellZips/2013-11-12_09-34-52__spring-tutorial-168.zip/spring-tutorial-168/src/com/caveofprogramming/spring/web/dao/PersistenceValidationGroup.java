package com.caveofprogramming.spring.web.dao;

public interface PersistenceValidationGroup {

}
