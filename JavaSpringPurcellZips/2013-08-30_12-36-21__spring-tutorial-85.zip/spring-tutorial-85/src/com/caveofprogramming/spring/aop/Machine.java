package com.caveofprogramming.spring.aop;

public interface Machine {

}
