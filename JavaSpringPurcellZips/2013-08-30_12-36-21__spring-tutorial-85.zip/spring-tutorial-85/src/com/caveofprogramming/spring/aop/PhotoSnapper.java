package com.caveofprogramming.spring.aop;

public interface PhotoSnapper {

}
