package com.caveofprogramming.spring.aop;

public class Camera {
	public void snap() {
		System.out.println("SNAP!");
	}
}
