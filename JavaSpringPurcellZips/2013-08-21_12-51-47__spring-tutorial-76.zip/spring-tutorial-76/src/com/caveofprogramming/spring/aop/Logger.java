package com.caveofprogramming.spring.aop;

public class Logger {
	public void aboutToTakePhoto() {
		System.out.println("About to take photo...");
	}
}
